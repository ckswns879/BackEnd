package com.ruby.paper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
